# Android-Calculator
An easy Android calculator with numbers, operators, square root, brackets and trigonometric functions. 
